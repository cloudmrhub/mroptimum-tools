import json
import os
import requests
import boto3
from botocore.exceptions import ClientError

DATA_BUCKET_NAME = os.environ.get('DataBucketName')
RESULTS_BUCKET_NAME = os.environ.get('ResultsBucketName')
GeometryOptions = ['mask', 'materialdensity', 'bloodperfusion', 'heatcapacity', 'thermalconductivity', 'metabolism', 'sar', 'told'];
ParameterOptions = ['air', 'blood'];
OtherOptions = ['heatingtime'];

# Reads a local file and returns it given the path.
def read_file(file_path):
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
        return data
    except Exception as e:
        print(e)
        raise e

# Downloads a file from S3 given a bucket, file key and s3 boto client.
# Returns local path to that file
def download_from_s3(bucket, file, s3=None):
    try: 
        print("Downloading File: " + file + ", Bucket:" + bucket)
        destination_path = '/tmp/' + os.path.basename(file)
        s3.download_file(bucket, file, destination_path)
        print("Completed Downloading File: " + file + ", Bucket:" + bucket)
        return destination_path
    except ClientError as e:
        print(e)
        if e.response['Error']['Code'] == '404':
            # Object doesn't exist, return None or handle as needed
            print("File not found: " + file)
            return None
        else:
            # Other S3-related error occurred, re-raise the exception
            print("Error downloading file: " + file)
            raise e

def handler(event, context):
    # Get the bucket name and file key.
    # This comes from the event which triggered the function.
    # In our case this is an object being created in the jobs bucket.
    job_bucket = event['Records'][0]['s3']['bucket']['name']
    job_file_key = event['Records'][0]['s3']['object']['key']
    print('Bucket: ' + job_bucket + ', Key: ' + job_file_key)

    try:
        s3_client = boto3.client('s3')
        # Download the entire object which describes the job and read the json file.
        job_file_path = download_from_s3(job_bucket, job_file_key, s3_client)
        if job_file_path is None:
            return {
                "statusCode": 404,
                "body": json.dumps({
                    "error": "Job file not found",
                }),
            }

        job_data = read_file(job_file_path)
        pipeline_id = job_data["task"]["pipeline"][0]["pipelineId"]
        options = job_data["task"]["pipeline"][0]["options"]
        print('Options:')
        print(options)
        # Download all the geometry files
        config = {}
        for option in GeometryOptions:
            local_geometry_file_path = download_from_s3(DATA_BUCKET_NAME, options[option]["filename"], s3_client)
            if local_geometry_file_path is None:
                return {
                    "statusCode": 404,
                    "body": json.dumps({
                        "error": "Geometry data file not found",
                    }),
                }
            config[option] = local_geometry_file_path

        for option in ParameterOptions:
            config[option] = options[option]

        for option in OtherOptions:
            config[option] = options[option]

        print('Config:')
        print(config)

        # TODO: RUN CALCULATIONS HERE
        # ...
        # ...

        # Upload results to the results bucket
        # s3_client.put_object(Bucket=RESULTS_BUCKET_NAME, Key=job_file_key, Body=json.dumps(config))
        # For now we are uploading this fakeoutput.zip file to the results bucket. It should instead
        # be the resulting zip of the TESS calculations which gets uploaded
        s3_client.upload_file('fakeoutput.zip',RESULTS_BUCKET_NAME, 'zipped/' + pipeline_id + '.zip')
        print('Uploaded results to: ' + RESULTS_BUCKET_NAME + '::' + pipeline_id + '.zip')

        # TODO: Update the pipeline db and set task to complete
        # r = requests.post(
        #     'https://cloudmrhub.com/api/pipeline/completed/{pipeline_id}'.format(pipeline_id),
        #     json={ 'output': 'zipped/' + pipeline_id + '.zip' },
        # )
        # print(r.text)

        return {
            'statusCode': 200,
            'body': json.dumps({
                "results":{
                    "key":pipeline_id + '.zip',
                    "bucket":RESULTS_BUCKET_NAME
                }
            })
        }

    except Exception as e:
        print(e)
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            }),
        }
