import json
import requests
import boto3
import os
def getHeadersForRequests():
    return {"Content-Type": "application/json","User-Agent": 'My User Agent 1.0','From': 'theweblogin@iam.com'}

def getHeadersForRequestsWithToken(token):
    headers = getHeadersForRequests()
    headers["Authorization"]= token
    return headers
    
def lambda_handler(event, context):
    """
    Create a job in the TESS pipeline.

    Args:
        event: The event that triggered the Lambda function.
        context: The context of the Lambda function.

    Returns:
        The response object.
    """

    # Get the body of the event.
    
    
    body = json.loads(event['body'])

    # Get the headers from the event object.
    headers = event['headers']
    # Get the authorization header.
    authorization_header = headers['Authorization']
    print(authorization_header)
    
    # Get the application and pipeline names.
    application = body['application']
    pipeline = body['pipeline'][0]
    
    subapplication = pipeline['subApplication']
    alias = pipeline['alias']
    options = pipeline['options']
    
    data2={"application":application,"alias":alias}

    r2=requests.post('https://cloudmrhub.com/api/pipeline/request', data=json.dumps(data2), headers=getHeadersForRequestsWithToken(authorization_header))
    
    R=r2.json()
    print(R)
    
    bucket = os.environ.get("JobBucketName")
    print(bucket)

    
    
    pipeline_id = R["pipeline"]

    # Create a job object.
    job = {
        'task': {
            'application': application,
            'pipeline': [
                {
                    'id': pipeline_id,
                    'subApplication': subapplication,
                    'alias': alias,
                    'options': options,
                    'application': application,
                    'token': authorization_header,
                    'pipelineId': pipeline_id
                }
            ]
        }
    }
    print(job)
    # Write the job to the S3 bucket.
    s3 = boto3.client('s3')
    key = f'{pipeline_id}.json'
    s3.put_object(Bucket=bucket, Key=key, Body=json.dumps(job))

    # Return the response object.
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Successfully scheduled a job - {}'.format(key),
            'alias': key,
            'job': json.dumps(job)
        })
    }