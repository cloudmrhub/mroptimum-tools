import { randomUUID } from "crypto"
import axios from 'axios';
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
const REGION = process.env.JobBucketRegion || 'us-east-1';
const s3 = new S3Client({ region: REGION })

/**
 * These are the different parameters that are used for TESS computations.
 * They should all be defined in the `options` object.
 * 
 * The geometryOptions should each be an object and link to an associated
 * geometry file in an S3 bucket, eg:
 * "mask": {
 *     "id": 0,
 *     "filename": "<file>.nii.gz",
 *     "link": "",
 *     "state": ""  
 * }
 * 
 * The parameter options are objects with further breakdown, eg:
 * "air": {
 *     "temperature": 293,
 *     "capacity": 1000,
 *     "density": 3600
 * }
 * 
 * Other options will simply be a key:value pair
 */
const geometryOptions = ['mask', 'materialdensity', 'bloodperfusion', 'heatcapacity', 'thermalconductivity', 'metabolism', 'sar', 'told'];
const parameterOptions = ['air', 'blood'];
const otherOptions = ['heatingTime'];

// This validates the body, ensuring the required fields are present.
const getBodyErrors = (body) => {
    if (!body) {
        return {
        statusCode: 400,
        body: JSON.stringify({
            error: 'Missing field - Body required'
        })
        } 
    }

    const { application, pipeline } = body;
    if (!application || !pipeline || !pipeline.length) {
        // Error - missing field
        return {
            statusCode: 400,
            body: JSON.stringify({
            error: 'Missing field - application or pipeline missing in body'
            })
        };
    }


    const [pipelineObject] = pipeline;
    const { subApplication, alias, options } = pipelineObject;
    if (!subApplication || !alias || !options) {
        // Error - missing field
        return {
            statusCode: 400,
            body: JSON.stringify({
            error: 'Missing field - subApplication, alias or options missing in body.pipeline[0]'
            })
        };
    }


    const geometryOptionError = geometryOptions.find(option => {
        return !Object.keys(options).includes(option)
    });
    if (geometryOptionError) {
        return {
        statusCode: 400,
        body: JSON.stringify({
            error: `Missing geometry option - ${geometryOptionError} missing`
        })
        };
    }


    const parameterOptionError = parameterOptions.forEach(option => {
        return !Object.keys(options).includes(option)
    })
    if (parameterOptionError) {
        return {
        statusCode: 400,
        body: JSON.stringify({
            error: `Missing geometry option - ${parameterOptionError} missing`
        })
        };
    }

    const otherOptionError = otherOptions.forEach(option => {
        return !Object.keys(options).includes(option)
    })
    if (otherOptionError) {
        return {
        statusCode: 400,
        body: JSON.stringify({
            error: `Missing other option - ${otherOptionError} missing`
        })
        };
    }

    return undefined;
}

export const handler = async (event) => {
    const { headers = {} } = event;
    const authorizationHeader = headers['Authorization'] || headers['authorization'];
    const cookieHeader = headers['Cookie'];
    console.log(cookieHeader)

    const body = JSON.parse(event.body)
    const hasBodyErrors = getBodyErrors(body);

    if (hasBodyErrors) {
        return hasBodyErrors;
    }

    const { application, pipeline } = body;
    const [tessPipelineObject] = pipeline;
    const { subApplication, alias, options } = tessPipelineObject;

    try {
        const pipelineId = randomUUID();
        console.log("authorizationHeader");
        console.log(authorizationHeader);
        // TODO: Create pipeline record in cmrhub and get pipeline ID
        const pipelineResp = await axios({
            method: 'post',
            url: 'https://cloudmrhub.com/api/pipeline/request',
            headers: {
                'Accept': '*/*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Authorization': authorizationHeader,
                // 'Cookie': cookieHeader,
                'Content-Type': 'application/json',
                'From': 'io.email@gmail.com',
                'User-Agent': 'curl'
            },
            data: {
                application,
                alias
            }
        });
        const { data: pipelineRespData } = pipelineResp;
        console.log(pipelineRespData);
        
        if (!pipelineRespData.id || !pipelineRespData.pipeline) {
            throw new Error('Cloud MR Hub error requesting pipeline', pipelineRespData);
        }

        const jobBody = {
            task: {
                application,
                pipeline: [
                    {
                    id: pipelineRespData.id,
                    subApplication,
                    alias,
                    options,
                    application,
                    token: authorizationHeader,
                    pipelineId
                    }
                ]
            }
        }
        const key = `${pipelineId}.json`
        const s3Params = {
            Bucket: process.env.JobBucketName,
            Key:  key,
            Body: JSON.stringify(jobBody)
        };
        const command = new PutObjectCommand(s3Params);
        await s3.send(command)
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: `Sucessfully scheduled a job - ${key}`,
                alias: key,
                job: JSON.stringify(jobBody)
            })
        } 
    } catch (err) {
        console.log(err);
        return {
            statusCode: 400,
            body: JSON.stringify({
                error: err
            })
        };
    }
};
